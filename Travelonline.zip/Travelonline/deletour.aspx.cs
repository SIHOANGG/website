﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Detail.aspx");
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        int id = int.Parse(Request.QueryString["ID"]);
        int cmnd = int.Parse(txtCMND.Text);
        int matour = int.Parse(Request.QueryString["MATOUR"]);
        int sl = int.Parse(Request.QueryString["sl"]);
        Khachhangbo bo=new Khachhangbo();
        if (bo.huytour(id, cmnd))
        {
            //okay
            ToursBO tbo = new ToursBO();
            int temp = tbo.sochotrong(matour) + sl;
            tbo.tru(matour, temp);
            Response.Write("<Script>alert('Hủy tour thành công.')</script>");
            Response.Redirect("Statistics.aspx");
        }
        else
            Response.Write("<Script>alert('Hủy tour thành công.')</script>");


    }
}