﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //kiem tra xem nguoi dung da dang nhap chua
        if(Session.Contents["username"]!=null)
        {
            Response.Redirect("Default.aspx");
        }
        else
        {
            if (Request.QueryString.Get("type") != null)
            {
                switch (Request.QueryString.Get("type"))
                {
                    case "notlg":
                        txtError.Text = "Xin vui lòng đăng nhập vào trang web";
                        break;
                }
            }
        }
    }
    protected void bt_clear_Click(object sender, EventArgs e)
    {
        //xoa cac du lieu da duoc ghi trong textbox
        if (IsPostBack == true)
        {
            txt_username.Text = "";
            txt_password.Text = "";
        }
    }
    protected void bt_login_Click(object sender, EventArgs e)
    {
        taikhoanbo bo = new taikhoanbo();

        string pass = mahoa.md5(txt_password.Text);
        int quyen = bo.checklogin(txt_username.Text,pass);
        if (quyen > 0)
        {
            //khoi tao bien session 
            Session.Add("username", txt_username.Text);
            Session.Add("pass", pass);
            Session.Add("quyen",quyen);
            if (txtRemember.Checked)
            {
                HttpCookie cookie = new HttpCookie("UserInfo");
                if (Request.Browser.Cookies == true)
                {
                    if (Request.Cookies["UserInfo"] != null)
                    {
                        cookie.Expires = DateTime.Now.AddDays(-1);
                    }
                    else
                    {
                        //cookie = new HttpCookie("UserInfo");
                        cookie["UserInfo"] = txt_username.Text;
                        cookie.Expires = DateTime.Now.AddDays(30);
                        Response.Cookies.Add(cookie);

                    }
                }
            }
            if (quyen == 1)
            {
                Response.Redirect("Admin/Default.aspx");
            }
            if (quyen == 3)
            {
                Response.Redirect("Default.aspx");
            }
        }
        else
        {
            txtError.Text = "Username hoặc Password không đúng.Vui lòng thử lại";
        }
    }
}
