﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class webcontrol_thongtinchitiettour : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load();
            
        }
    }

    private void load()
    {
        int matour=int.Parse(Request.QueryString["matour"]);
        ToursBO bo = new ToursBO();
        ToursData tour = bo.chitiettour(matour);
        lb_tentour.Text = tour.TENTOUR1;
        lb_noidung.Text = tour.NOIDUNG1;
        lb_giaca.Text = tour.GIACA1.ToString();
        lb_ngaydi.Text = tour.NGAYKHOIHANH1.ToString();
        lb_songay.Text = tour.SONGAY1.ToString();
        lb_songuoi.Text = tour.TONGSO1.ToString();
        image_tour.ImageUrl = "~/image/"+tour.HINHANH1;
        lb_diemden.Text = tour.DIEMDEN1.ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int matour = int.Parse(Request.QueryString["matour"]);
        Response.Redirect("DatTour.aspx?ma=" + matour);
    }
}