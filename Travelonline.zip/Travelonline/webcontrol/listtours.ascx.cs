﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UC_listtours : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            ToursBO bo = new ToursBO();
            if (Request.QueryString["ma"] == null)
            {
                DataList1.DataSource = bo.getall();
                DataList1.DataBind();
            }
            else
            {
                DataList1.DataSource = bo.danhsachtheoMA(Request.QueryString["ma"].ToString());
                DataList1.DataBind();
            }
        }
    }
}