using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class webcontrol_Menu : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    void createmenu(Menu menu,DataTable bang)
    {
        foreach(DataRow dong in bang.Rows)
        {
            menu.Items.Add(new MenuItem(dong[0].ToString(), dong[1].ToString()));
        }
    }
}
