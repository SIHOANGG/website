﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class webcontrol_chitiettour : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ToursBO bo = new ToursBO();
        GridView1.DataSource = bo.getall();
        GridView1.DataBind();
    }
}