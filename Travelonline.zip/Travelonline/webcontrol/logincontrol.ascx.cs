﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class logincontrol : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //goi ham login
        dangnhap();
    }
    protected void dangnhap()
    {
        if(Session.Contents["username"]==null)
        {
            table1.Visible = true;
        }
        else
        {
            table2.Visible = true;
            txtUsername.Text = "Welcome :" + Session.Contents["username"];
        }
    }
}
