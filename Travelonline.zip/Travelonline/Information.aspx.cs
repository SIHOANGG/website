﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Thongtin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        if (Session["username"] == null)
            Response.Redirect("Login.aspx");
        else
        {
            load();
        }
    }

    private void load()
    {
        taikhoanbo bo = new taikhoanbo();
        Taikhoandata dt = new Taikhoandata();
        dt = bo.getoneaccount(Session["username"].ToString());
        txt_email.Text = dt.EMAIL1;
        txt_diachi.Text = dt.ADDRESS1;
        if(dt.GENDER1.Trim().Equals("Nam"))
            rdo_nam.Checked = true;
        else
            rdo_nu.Checked = true;

    }

    protected void btn_capnhat_Click(object sender, EventArgs e)
    {
        Taikhoandata tk = new Taikhoandata();
        taikhoanbo bo=new taikhoanbo();
        tk.EMAIL1 = txt_email.Text;
        tk.ADDRESS1 = txt_diachi.Text;
        tk.USERNAME1 = Session["username"].ToString();
        if (rdo_nam.Checked == true)
            tk.GENDER1 = "Nam";
        else
            tk.GENDER1 = "Nu";
        if (bo.updateinformation(tk))
        {
            Response.Write("<Script>alert('Cập nhật thành công.')</Script>");
            load();
        }
        else
        {
            Response.Write("<Script>alert('Cập nhật không thành công.')</Script>");
        }
    }
}
