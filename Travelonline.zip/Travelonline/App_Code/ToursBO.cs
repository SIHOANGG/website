﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ToursBO
/// </summary>
public class ToursBO
{
    public List<ToursData> getall()
    {
        Toursdb db = new Toursdb();
        return db.getall();
    }

    public List<ToursData> danhsachtheoMA(string MA)
    {
        Toursdb db = new Toursdb();
        return db.danhsachtheoMA(MA);
    }

    public ToursData chitiettour(int matour)
    {
        Toursdb db = new Toursdb();
        return db.chitiettour(matour);
    }
    public int sochotrong(int matour)
    {
        Toursdb db = new Toursdb();
        return db.sochotrong(matour);
    }
    public bool tru(int matour, int tongso)
    {
        Toursdb db = new Toursdb();
        return db.tru(matour, tongso);
    }
    public bool inserttour(ToursData tour)
    {
        Toursdb db = new Toursdb();
        return db.inserttour(tour);
    }
    public bool updatetour(ToursData tour)
    {
        Toursdb db = new Toursdb();
        return db.updateto(tour);
    }
    public bool DeleteOrRetoseTO(int MATOUR, bool status)
    {
        Toursdb db = new Toursdb();
        return db.DeleteOrRetoseTOUR(MATOUR, status);
    }

}