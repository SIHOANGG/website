﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for KhachhangData
/// </summary>
public class KhachhangData
{
	public KhachhangData()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private int ID;

    public int ID1
    {
        get { return ID; }
        set { ID = value; }
    }
    private string USERNAME;

    public string USERNAME1
    {
        get { return USERNAME; }
        set { USERNAME = value; }
    }
    private int CMND;

    public int CMND1
    {
        get { return CMND; }
        set { CMND = value; }
    }
    private string HOTEN;

    public string HOTEN1
    {
        get { return HOTEN; }
        set { HOTEN = value; }
    }
    private string DIENTHOAI;

    public string DIENTHOAI1
    {
        get { return DIENTHOAI; }
        set { DIENTHOAI = value; }
    }
    private string TINHTHANH;

    public string TINHTHANH1
    {
        get { return TINHTHANH; }
        set { TINHTHANH = value; }
    }
    private string NGAYDANGKY;

    public string NGAYDANGKY1
    {
        get { return NGAYDANGKY; }
        set { NGAYDANGKY = value; }
    }
    private int SONGUOI;

    public int SONGUOI1
    {
        get { return SONGUOI; }
        set { SONGUOI = value; }
    }
    private int MATOUR;

    public int MATOUR1
    {
        get { return MATOUR; }
        set { MATOUR = value; }
    }
    private string TENTOUR;

    public string TENTOUR1
    {
        get { return TENTOUR; }
        set { TENTOUR = value; }
    }

}