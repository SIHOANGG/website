﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Toursdb
/// </summary>
public class Toursdb
{
    public List<ToursData> getall()
    {
        List<ToursData> tdb = new List<ToursData>();
        ConnectDB cn = new ConnectDB();
        string sql = "select * from tour where status = 'false'";
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        ToursData tour = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                tour = new ToursData();
                tour.MATOUR1 = int.Parse(reader["MATOUR"].ToString());
                tour.TENTOUR1 = reader["TENTOUR"].ToString();
                tour.NOIDUNG1 = reader["NOIDUNG"].ToString();
                tour.HINHANH1 = reader["HINHANH"].ToString();
                tour.SONGAY1 = int.Parse(reader["SONGAY"].ToString());
                tour.GIACA1 = int.Parse(reader["GIACA"].ToString());
                tour.PHUONGTIEN1 = reader["PHUONGTIEN"].ToString();
                tour.NGAYKHOIHANH1 = DateTime.Parse(reader["NGAYKHOIHANH"].ToString());
                tour.DIEMDEN1 = reader["DIEMDEN"].ToString();
                tour.NGAYDANGTIN1 = DateTime.Parse(reader["NGAYDANGTIN"].ToString());
                tour.MA1 = reader["MA"].ToString();
                tour.MOTA1 = reader["MOTA"].ToString();
                tdb.Add(tour);
            }
        }
        return tdb;
    }
    public List<ToursData> danhsachtheoMA(string MA)
    {
        List<ToursData> tdb = new List<ToursData>();
        ConnectDB cn = new ConnectDB();
        string sql = "select * from tour where MA=@MA";
        cn.Cmd.Parameters.Add("@MA", MA);
        //tuong tự cho trong hop khac nhieu parameter
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        ToursData tour = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                tour = new ToursData();
                tour.MATOUR1 = int.Parse(reader["MATOUR"].ToString());
                tour.TENTOUR1 = reader["TENTOUR"].ToString();
                tour.NOIDUNG1 = reader["NOIDUNG"].ToString();
                tour.HINHANH1 = reader["HINHANH"].ToString();
                tour.SONGAY1 = int.Parse(reader["SONGAY"].ToString());
                tour.GIACA1 = int.Parse(reader["GIACA"].ToString());
                tour.PHUONGTIEN1 = reader["PHUONGTIEN"].ToString();
                tour.NGAYKHOIHANH1 = DateTime.Parse(reader["NGAYKHOIHANH"].ToString());
                tour.DIEMDEN1 = reader["DIEMDEN"].ToString();
                tour.NGAYDANGTIN1 = DateTime.Parse(reader["NGAYDANGTIN"].ToString());
                tour.MA1 = reader["MA"].ToString();
                tour.MOTA1 = reader["MOTA"].ToString();
                tdb.Add(tour);
            }
        }
        return tdb;
    }

    public ToursData chitiettour(int Matour)
    {
        ConnectDB cn = new ConnectDB();
        string sql = "select * from tour where MATOUR=@MAOUR";
        cn.Cmd.Parameters.Add("@MAOUR", Matour);
        //tuong tự cho trong hop khac nhieu parameter
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        ToursData tour = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                tour = new ToursData();
                tour.MATOUR1 = int.Parse(reader["MATOUR"].ToString());
                tour.TENTOUR1 = reader["TENTOUR"].ToString();
                tour.NOIDUNG1 = reader["NOIDUNG"].ToString();
                tour.HINHANH1 = reader["HINHANH"].ToString();
                tour.SONGAY1 = int.Parse(reader["SONGAY"].ToString());
                tour.GIACA1 = int.Parse(reader["GIACA"].ToString());
                tour.PHUONGTIEN1 = reader["PHUONGTIEN"].ToString();
                tour.NGAYKHOIHANH1 = DateTime.Parse(reader["NGAYKHOIHANH"].ToString());
                tour.DIEMDEN1 = reader["DIEMDEN"].ToString();
                tour.NGAYDANGTIN1 = DateTime.Parse(reader["NGAYDANGTIN"].ToString());
                tour.MA1 = reader["MA"].ToString();
                tour.MOTA1 = reader["MOTA"].ToString();
                
            }
        }
        return tour;

    }
    public bool updateto(ToursData tdt)
    {
        try
        {
            string sql = @"UPDATE TOUR SET TENTOUR=@TENTOUR,SONGAY=@SONGAY,GIACA=@GIACA,PHUONGTIEN=@PHUONGTIEN,TONGSO=@TONGSO,DIEMDEN=@DIEMDEN WHERE MATOUR=@MATOUR";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("MATOUR", tdt.MATOUR1);
            cn.Cmd.Parameters.Add("@TENTOUR", tdt.TENTOUR1);
            //cn.Cmd.Parameters.Add("@MOTA", tdt.MOTA1);
            //cn.Cmd.Parameters.Add("@NOIDUNG", tdt.NOIDUNG1);
            //cn.Cmd.Parameters.Add("@HINHANH", tdt.HINHANH1);
            cn.Cmd.Parameters.Add("@SONGAY", tdt.SONGAY1);
            cn.Cmd.Parameters.Add("@GIACA", tdt.GIACA1);
            cn.Cmd.Parameters.Add("@PHUONGTIEN", tdt.PHUONGTIEN1);
            //cn.Cmd.Parameters.Add("@NGAYKHOIHANH", tdt.NGAYKHOIHANH1);
            cn.Cmd.Parameters.Add("@TONGSO", tdt.TONGSO1);
           // cn.Cmd.Parameters.Add("@NGAYDANGTIN", tdt.NGAYDANGTIN1);
            cn.Cmd.Parameters.Add("@DIEMDEN", tdt.DIEMDEN1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    public bool inserttour(ToursData tdt)
    {
        try
        {
            string sql = @"insert into TOUR(TENTOUR,NOIDUNG,HINHANH,SONGAY,GIACA,PHUONGTIEN,NGAYKHOIHANH,TONGSO,DIEMDEN,NGAYDANGTIN,MA,MOTA) values(@TENTOUR,@NOIDUNG,@HINHANH,@SONGAY,@GIACA,@PHUONGTIEN,@NGAYKHOIHANH,@TONGSO,@DIEMDEN,GETDATE(),@MA,@MOTA)";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@TENTOUR", tdt.TENTOUR1);
            cn.Cmd.Parameters.Add("@MOTA", tdt.MOTA1);
            cn.Cmd.Parameters.Add("@NOIDUNG", tdt.NOIDUNG1);
            cn.Cmd.Parameters.Add("@HINHANH", tdt.HINHANH1);
            cn.Cmd.Parameters.Add("@SONGAY", tdt.SONGAY1);
            cn.Cmd.Parameters.Add("@GIACA", tdt.GIACA1);
            cn.Cmd.Parameters.Add("@PHUONGTIEN", tdt.PHUONGTIEN1);
            cn.Cmd.Parameters.Add("@NGAYKHOIHANH", tdt.NGAYKHOIHANH1);
            cn.Cmd.Parameters.Add("@TONGSO", tdt.TONGSO1);
            cn.Cmd.Parameters.Add("@DIEMDEN", tdt.DIEMDEN1);
            cn.Cmd.Parameters.Add("@MA", tdt.MA1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    /*public bool deletetour(ToursData tdt)
    {
        try
        {
            string sql = "DELETE FROM TOUR WHERE MATOUR=@MATOUR"; ConnectDB cn = new ConnectDB();
            return true;

        }
        catch { return false; }
    }*/

    public int sochotrong(int matour)
    {
        try
        {
            ConnectDB cn = new ConnectDB();
            string sql = "select TONGSO from TOUR where MATOUR=@matour";
            cn.Cmd.Parameters.Add("@matour", matour);
            cn.Cmd.CommandText = sql;
            return int.Parse(cn.Cmd.ExecuteScalar().ToString());
        }
        catch { return -1; }
    }

    public bool tru(int matour, int tongso)
    {
        try
        {
            ConnectDB cn = new ConnectDB();
            string sql = "update tour set tongso=@tongso where matour=@matour";
            cn.Cmd.Parameters.Add("@tongso", tongso);
            cn.Cmd.Parameters.Add("@matour", matour);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    public bool DeleteOrRetoseTOUR(int MATOUR, bool status)
    {
        try
        {
            string sql = "update TOUR set status=@status where MATOUR=@MATOUR";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@status", status);
            cn.Cmd.Parameters.Add("@MATOUR", MATOUR);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    
}