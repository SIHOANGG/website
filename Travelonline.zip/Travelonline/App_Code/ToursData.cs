﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ToursData
/// </summary>
public class ToursData
{
	public ToursData()
	{
		
	}
    int MATOUR;

    public int MATOUR1
    {
        get { return MATOUR; }
        set { MATOUR = value; }
    }
    string TENTOUR; 

    public string TENTOUR1
    {
        get { return TENTOUR; }
        set { TENTOUR = value; }
    }
    string MOTA;

    public string MOTA1
    {
        get { return MOTA; }
        set { MOTA = value; }
    }
    string NOIDUNG;

    public string NOIDUNG1
    {
        get { return NOIDUNG; }
        set { NOIDUNG = value; }
    }
    string HINHANH;

    public string HINHANH1
    {
        get { return HINHANH; }
        set { HINHANH = value; }
    }
    int SONGAY;

    public int SONGAY1
    {
        get { return SONGAY; }
        set { SONGAY = value; }
    }
    int GIACA;

    public int GIACA1
    {
        get { return GIACA; }
        set { GIACA = value; }
    }
    string PHUONGTIEN;

    public string PHUONGTIEN1
    {
        get { return PHUONGTIEN; }
        set { PHUONGTIEN = value; }
    }
    DateTime NGAYKHOIHANH;

    public DateTime NGAYKHOIHANH1
    {
        get { return NGAYKHOIHANH; }
        set { NGAYKHOIHANH = value; }
    }
    int TONGSO;

    public int TONGSO1
    {
        get { return TONGSO; }
        set { TONGSO = value; }
    }
    string DIEMDEN;

    public string DIEMDEN1
    {
        get { return DIEMDEN; }
        set { DIEMDEN = value; }
    }
    DateTime NGAYDANGTIN;

    public DateTime NGAYDANGTIN1
    {
        get { return NGAYDANGTIN; }
        set { NGAYDANGTIN = value; }
    }
    string MA;

    public string MA1
    {
        get { return MA; }
        set { MA = value; }
    }

}