﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Khachhangbo
/// </summary>
public class Khachhangbo
{
    public List<KhachhangData> getallkhachhang()
    {
        khachhangdb db = new khachhangdb();
        return db.getallkhachhang();
    }

    public bool Insert(KhachhangData kh)
    {
        khachhangdb db=new khachhangdb();
        return db.Insert(kh);
    }
    public bool Update(KhachhangData kh)
    {
        khachhangdb db = new khachhangdb();
        return db.update(kh);
    }
    public bool DeleteOrRetose(int id, bool status)
    {
        khachhangdb db = new khachhangdb();
        return db.DeleteOrRetose(id, status);
    }
    public List<KhachhangData> danhsachkh(string username)
        
    {
        khachhangdb db = new khachhangdb();
        return db.danhsachtheousername(username);
    }

    public bool huytour(int ID, int CMND)
    {
        khachhangdb db = new khachhangdb();
        return db.huytour(ID, CMND);
    }


}