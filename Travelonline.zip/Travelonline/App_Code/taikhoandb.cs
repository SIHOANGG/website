﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
/// <summary>
/// Summary description for taikhoandb
/// </summary>
public class taikhoandb
{
	public taikhoandb()
	{
	}

    public int checklogin(string username, string pass)
    {
        try
        {
            string sql = "select ACTIVATE from taikhoan where username=@username and pass=@pass";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@username", username);
            cn.Cmd.Parameters.Add("@pass", pass);
            cn.Cmd.CommandText = sql;
            int quyen = int.Parse(cn.Cmd.ExecuteScalar().ToString());
            return quyen;
        }
        catch { return -1; }
    }
    public bool dangky(Taikhoandata dktk)
    {
        try
        {
            string sql = @"INSERT INTO TAIKHOAN(USERNAME,PASS,EMAIL,GENDER,ADDRESS,ACTIVATE) 
                        VALUES(@USERNAME,@PASS,@EMAIL,@GENDER,@ADDRESS,'3')";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@USERNAME", dktk.USERNAME1);
            cn.Cmd.Parameters.Add("@PASS", dktk.PASS1);
            cn.Cmd.Parameters.Add("@EMAIL", dktk.EMAIL1);
            cn.Cmd.Parameters.Add("@GENDER", dktk.GENDER1);
            cn.Cmd.Parameters.Add("@ADDRESS", dktk.ADDRESS1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    public List<Taikhoandata> getalltaikhoang()
    {
        List<Taikhoandata> tkdb = new List<Taikhoandata>();
        ConnectDB cn = new ConnectDB();
        string sql = "select * from taikhoan";
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        Taikhoandata tk = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                tk = new Taikhoandata();
                tk.USERNAME1 = reader["USERNAME"].ToString();
                tk.PASS1 = reader["PASS"].ToString();
                tk.EMAIL1 = reader["EMAIL"].ToString();
                tk.ADDRESS1 = reader["ADDRESS"].ToString();
                tk.ACTIVATE1 = int.Parse(reader["ACTIVATE"].ToString());
                tk.GENDER1 = reader["GENDER"].ToString();
                tkdb.Add(tk);
            }
        }
        return tkdb;
    }
    public bool updatechangepass(string username,string pass)
    {
        try
        {
            string sql = @"UPDATE TAIKHOAN SET PASS = @PASS WHERE USERNAME=@USERNAME";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@PASS",pass);
            cn.Cmd.Parameters.Add("@USERNAME", username);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }

    public bool updateinformation(Taikhoandata tk)
    {
        try
        {
            string sql = @"UPDATE TAIKHOAN SET EMAIL = @EMAIL, GENDER=@GENDER, ADDRESS=@ADDRESS WHERE USERNAME=@USERNAME";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@EMAIL", tk.EMAIL1);
            cn.Cmd.Parameters.Add("@GENDER", tk.GENDER1);
            cn.Cmd.Parameters.Add("@ADDRESS", tk.ADDRESS1);
            cn.Cmd.Parameters.Add("@USERNAME", tk.USERNAME1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }

    public Taikhoandata get1taikhoang(string username)
    {
        ConnectDB cn = new ConnectDB();
        string sql = "select * from taikhoan where USERNAME=@USERNAME";
        cn.Cmd.Parameters.Add("@USERNAME", username);
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        Taikhoandata tk = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                tk = new Taikhoandata();
                tk.USERNAME1 = reader["USERNAME"].ToString();
                tk.PASS1 = reader["PASS"].ToString();
                tk.EMAIL1 = reader["EMAIL"].ToString();
                tk.ADDRESS1 = reader["ADDRESS"].ToString();
                tk.ACTIVATE1 = int.Parse(reader["ACTIVATE"].ToString());
                tk.GENDER1 = reader["GENDER"].ToString();
                
            }
        }
        return tk;
    }
    public bool phanquyenm(Taikhoandata tk)
    {
        try
        {
            string sql = @"UPDATE TAIKHOAN SET ACTIVATE=@ACTIVATE WHERE USERNAME=@USERNAME";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@USERNAME", tk.USERNAME1);
            cn.Cmd.Parameters.Add("@ACTIVATE",tk.ACTIVATE1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
}