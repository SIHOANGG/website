﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for ConnectDB
/// </summary>
public class ConnectDB
{

    string chuoiketnoi = ConfigurationManager.ConnectionStrings["dulieuConnectionString"].ToString();
        SqlConnection cn;
        SqlCommand cmd;

        public ConnectDB()
        {
            cn = new SqlConnection(chuoiketnoi);
            cn.Open();
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = cn;
        }

        public SqlCommand Cmd
        {
            get { return cmd; }
            set { cmd = value; }
        }
    

}