﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// Summary description for khachhangdb
/// </summary>
public class khachhangdb
{
    public List<KhachhangData> getallkhachhang()
    {
        List<KhachhangData> khdb = new List<KhachhangData>();
        ConnectDB cn = new ConnectDB();
        string sql = "select * from khachhang where ISELETED=0";
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        KhachhangData kh = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                kh = new KhachhangData();
                kh.ID1 = int.Parse(reader["ID"].ToString());
                kh.USERNAME1 = reader["USERNAME"].ToString();
                kh.CMND1 = int.Parse(reader["CMND"].ToString());
                kh.HOTEN1 = reader["HOTEN"].ToString();
                kh.DIENTHOAI1 = reader["DIENTHOAI"].ToString();
                kh.TINHTHANH1 = reader["TINHTHANH"].ToString();
                kh.NGAYDANGKY1 = reader["NGAYDANGKY"].ToString();
                kh.SONGUOI1 = int.Parse(reader["SONGUOI"].ToString());
                kh.MATOUR1 = int.Parse(reader["MATOUR"].ToString());
                khdb.Add(kh);
            }
        }
        return khdb;
    }
    public bool update(KhachhangData khdt)
    {
        try
        {
            string sql = @"UPDATE KHACHHANG SET HOTEN=@HOTEN,CMND=@CMND,DIENTHOAI=@DIENTHOAI, NGAYDANGKY = @NGAYDANGKY, SONGUOI= @SONGUOI,TINHTHANH = @TINHTHANH,MATOUR = @MATOUR
                        WHERE ID=@ID";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@HOTEN", khdt.HOTEN1);
            cn.Cmd.Parameters.Add("@CMND", khdt.CMND1);
            cn.Cmd.Parameters.Add("@DIENTHOAI", khdt.DIENTHOAI1);
            cn.Cmd.Parameters.Add("@NGAYDANGKY", khdt.NGAYDANGKY1);
            cn.Cmd.Parameters.Add("@SONGUOI", khdt.SONGUOI1);
            cn.Cmd.Parameters.Add("@TINHTHANH", khdt.TINHTHANH1);
            cn.Cmd.Parameters.Add("@MATOUR", khdt.MATOUR1);
            cn.Cmd.Parameters.Add("@ID", khdt.ID1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    public bool Insert(KhachhangData khdk)
    {
        try
        {
            string sql = @"INSERT INTO KHACHHANG(HOTEN,CMND,DIENTHOAI,NGAYDANGKY,SONGUOI,TINHTHANH,USERNAME,MATOUR,ISELETED) 
                        VALUES(@HOTEN,@CMND,@DIENTHOAI,getdate(),@SONGUOI,@TINHTHANG,@USERNAME,@MATOUR,'FALSE')";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@HOTEN", khdk.HOTEN1);
            cn.Cmd.Parameters.Add("@CMND", khdk.CMND1);
            cn.Cmd.Parameters.Add("@DIENTHOAI", khdk.DIENTHOAI1);
            cn.Cmd.Parameters.Add("@SONGUOI", khdk.SONGUOI1);
            cn.Cmd.Parameters.Add("@TINHTHANG", khdk.TINHTHANH1);
            cn.Cmd.Parameters.Add("@USERNAME", khdk.USERNAME1);
            cn.Cmd.Parameters.Add("@MATOUR", khdk.MATOUR1);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; } 
    }

    public bool DeleteOrRetose(int id,bool status)
    {
        try
        {
            string sql = "update khachhang set iseleted=@status where id=@id";
            ConnectDB cn = new ConnectDB();
            cn.Cmd.Parameters.Add("@status", status);
            cn.Cmd.Parameters.Add("@id", id);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
    public List<KhachhangData> danhsachtheousername(string username)
    {
        List<KhachhangData> kdb = new List<KhachhangData>();
        ConnectDB cn = new ConnectDB();
        string sql = "select KHACHHANG.MATOUR, TOUR.TENTOUR, SONGUOI, KHACHHANG.ID from TOUR,KHACHHANG where TOUR.MATOUR=KHACHHANG.MATOUR and USERNAME=@USERNAME and iseleted=0";
        cn.Cmd.Parameters.Add("@USERNAME", username);
        //tuong tự cho trong hop khac nhieu parameter
        cn.Cmd.CommandText = sql;
        SqlDataReader reader = cn.Cmd.ExecuteReader();
        KhachhangData tour = null;
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                tour = new KhachhangData();
                tour.MATOUR1 = int.Parse(reader["MATOUR"].ToString());
                tour.TENTOUR1 = reader["TENTOUR"].ToString();
                tour.SONGUOI1 = int.Parse(reader["SONGUOI"].ToString());
                tour.ID1 = int.Parse(reader["ID"].ToString());
                kdb.Add(tour);
            }

        }
        return kdb;
    }

    public bool huytour(int ID, int cmnd)
    {
        try
        {
            ConnectDB cn = new ConnectDB();
            string sql = "update khachhang set iseleted=1 where cmnd=@cmnd and ID=@ID";
            cn.Cmd.Parameters.Add("@cmnd", cmnd);
            cn.Cmd.Parameters.Add("@ID", ID);
            cn.Cmd.CommandText = sql;
            cn.Cmd.ExecuteNonQuery();
            return true;
        }
        catch { return false; }
    }
}