﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Taikhoandata
/// </summary>
public class Taikhoandata
{
	public Taikhoandata()
	{
	
	}
    private string USERNAME;

    public string USERNAME1
    {
        get { return USERNAME; }
        set { USERNAME = value; }
    }
    private string PASS;

    public string PASS1
    {
        get { return PASS; }
        set { PASS = value; }
    }
    private string EMAIL;

    public string EMAIL1
    {
        get { return EMAIL; }
        set { EMAIL = value; }
    }
    private string GENDER;

    public string GENDER1
    {
        get { return GENDER; }
        set { GENDER = value; }
    }
    private string ADDRESS;

    public string ADDRESS1
    {
        get { return ADDRESS; }
        set { ADDRESS = value; }
    }
    private int ACTIVATE;

    public int ACTIVATE1
    {
        get { return ACTIVATE; }
        set { ACTIVATE = value; }
    }
    
}