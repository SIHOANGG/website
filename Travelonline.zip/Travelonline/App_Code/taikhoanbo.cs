﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

/// <summary>
/// Summary description for taikhoanbo
/// </summary>
public class taikhoanbo
{
	public taikhoanbo()
	{
		
	}

    public int checklogin(string username, string pass)
    {
        taikhoandb db = new taikhoandb();
        return db.checklogin(username, pass);
    }

    public bool dangkybo(Taikhoandata dk)
    {
       taikhoandb dbtk = new taikhoandb();
       return dbtk.dangky(dk);
    }
    public List<Taikhoandata> getalltaikhoan()
    {
        taikhoandb dbt =new  taikhoandb();
        return dbt.getalltaikhoang();
    }

    public bool updatechangepass(string username, string pass)
    {
        taikhoandb tk = new taikhoandb();
        return tk.updatechangepass(username, pass);
    }
    public bool updateinformation(Taikhoandata tk)

    {
        taikhoandb db = new taikhoandb();
        //bool check;
        //check = db.updateinformation(tk);
        //return check;

        return db.updateinformation(tk);
    }
    public bool phanquyen(Taikhoandata tk)
    {
        taikhoandb db = new taikhoandb();
        return db.phanquyenm(tk);
    }


    public Taikhoandata getoneaccount(string username)
    {
        taikhoandb db = new taikhoandb();
        return db.get1taikhoang(username);
    }


}