﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_quanlytour : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            loadtk();

    }
    private void loadtk()
    {
        ToursBO bo = new ToursBO();
        GridView2.DataSource = bo.getall();
        GridView2.DataBind();
    }

    protected void GridView2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView2.EditIndex = -1;
        loadtk();
    }
    protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView2.EditIndex = e.NewEditIndex;
        loadtk();
    }
    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        ToursBO bo = new ToursBO();
        ToursData tour = new ToursData();
        tour.MATOUR1 = int.Parse(GridView2.DataKeys[e.RowIndex].Value.ToString());
        tour.TENTOUR1 = (GridView2.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox).Text;
        tour.SONGAY1 = int.Parse((GridView2.Rows[e.RowIndex].Cells[3].Controls[0] as TextBox).Text);
        tour.GIACA1 =int.Parse((GridView2.Rows[e.RowIndex].Cells[4].Controls[0] as TextBox).Text);
        tour.PHUONGTIEN1 = (GridView2.Rows[e.RowIndex].Cells[5].Controls[0] as TextBox).Text;
        tour.TONGSO1 = int.Parse((GridView2.Rows[e.RowIndex].Cells[6].Controls[0] as TextBox).Text);
        tour.DIEMDEN1 = (GridView2.Rows[e.RowIndex].Cells[7].Controls[0] as TextBox).Text;

        if (bo.updatetour(tour))
        {
            Response.Write("<Script>alert('Cap nhat thanh cong');</Script>");
            GridView2.EditIndex = -1;
            loadtk();
        }
        else
        {
            Response.Write("<Script>alert('Cap nhat khong thanh cong');</Script>");
        }
    }
    protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        ToursBO bo = new ToursBO();


        int MATOUR = int.Parse(GridView2.DataKeys[e.RowIndex].Value.ToString());
        if (bo.DeleteOrRetoseTO(MATOUR, true))
        {
            Response.Write("<Script>alert('xoa thanh cong');</Script>");
            loadtk();
        }
        else
        {
            Response.Write("<Script>alert('xoa khong thanh cong');</Script>");


        }
    }
}
