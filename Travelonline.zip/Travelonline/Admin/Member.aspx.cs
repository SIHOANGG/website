using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Admin_Member : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            loadtk();
    }
    private void loadtk()
    {
        taikhoanbo bo = new taikhoanbo();
        GridView2.DataSource = bo.getalltaikhoan();
        GridView2.DataBind();
    }
   
    

   
    
    protected void GridView2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView2.EditIndex = -1;
        loadtk();
    }
    protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        taikhoanbo bo = new taikhoanbo();
        Taikhoandata tk = new Taikhoandata();
        tk.USERNAME1 = GridView2.DataKeys[e.RowIndex].Value.ToString();
        tk.ACTIVATE1 = int.Parse((GridView2.Rows[e.RowIndex].Cells[6].Controls[0] as TextBox).Text);

        if (bo.phanquyen(tk))
        {
            Response.Write("<Script>alert('PHAN QUYEN THANH CONG');</Script>");
            GridView2.EditIndex = -1;
            loadtk();
        }
        else
        {
            Response.Write("<Script>alert('PHAN QUYEN THAT BAI');</Script>");
        }
    }
    protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView2.EditIndex = e.NewEditIndex;
        loadtk();
    }
}
