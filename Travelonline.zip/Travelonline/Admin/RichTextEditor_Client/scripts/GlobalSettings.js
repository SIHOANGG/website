//---Start---Smiley---Setting---
var smileyPath='Images/Smiley/';
var smileyImageType='gif';
var smileys=new Array('airplane','angel','angry','auto','baringteeth','beermug','birthdaycake','boy','brokenheart','camera','CatFace','Clock','CoffeeCup','Computer','Confused','Crying','Devil','Disappointed','DogFace','DontTellAnyone','Email','Embarrassed','EyeRolling','Filmstrip','GiftWithABow','Girl','GirlHug','GuyHug','Hot','IDontKnow','IslandWithAPalmTree','LightBulb','MobilePhone','Money','Nerd','Note','OpenMouthed','Party','Pizza','RedHeart','RedLips','RedRose','Sad','Sarcastic','SecretTelling','Sick','SleepingHalfMoon','Sleepy','Smile','SoccerBall','Star','Surprised','TelephoneReceiver','Thinking','ThumbsDown','ThumbsUp','TongueOut','Umbrella','WiltedRose','Wink');
//---End---Smiley---Setting---

//---Start---Symbols---Setting---
var symbols=new Array('quot','amp','lt','gt','euro','Aacute','aacute','Acirc','acirc','acute','AElig','aelig','Agrave','agrave','Aring','aring','Atilde','atilde','Auml','auml','brvbar','Ccedil','ccedil','cedil','cent','circ','copy','curren','deg','divide','Eacute','eacute','Ecirc','ecirc','Egrave','egrave','ETH','eth','Euml','euml','fnof','frac12','frac14','frac34','Iacute','iacute','Icirc','icirc','iexcl','Igrave','igrave','iquest','Iuml','iuml','laquo','macr','micro','middot','not','Ntilde','ntilde','Oacute','oacute','Ocirc','ocirc','OElig','oelig','Ograve','ograve','ordf','ordm','Oslash','oslash','Otilde','otilde','Ouml','ouml','para','plusmn','pound','raquo','reg','Scaron','scaron','sect','sup1','sup2','sup3','szlig','THORN','thorn','tilde','times','Uacute','uacute','Ucirc','ucirc','Ugrave','ugrave','uml','Uuml','uuml','Yacute','yacute','yen','Yuml','yuml','ndash','mdash','dagger','Dagger','permil','bull','hellip','oline','trade','part','sum','minus','radic','infin','int','asymp','ne','le','ge','loz','Alpha','alpha','Beta','beta','Gamma','gamma','Delta','delta','Epsilon','epsilon','Zeta','zeta','Eta','eta','Theta','theta','Iota','iota','Kappa','kappa','Lambda','lambda','Mu','mu','Nu','nu','Xi','xi','Omicron','omicron','Pi','pi','piv','Rho','rho','Sigma','sigma','sigmaf','Tau','tau','Upsilon','upsilon','Phi','phi','Chi','chi','Psi','psi','Omega','omega');
//---End---Symbols---Setting---

//---Start---Symbols---Setting---
var rteHelpUrl='Help/default.html';
//---End---Symbols---Setting---

