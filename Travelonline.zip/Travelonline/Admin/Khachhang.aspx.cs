﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Admin_Khachhang : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            load();
    }

    private void load()
    {
        Khachhangbo bo = new Khachhangbo();
        GridView1.DataSource = bo.getallkhachhang();
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Khachhangbo bo = new Khachhangbo();
        

        int id =int.Parse( GridView1.DataKeys[e.RowIndex].Value.ToString());
        if (bo.DeleteOrRetose(id, true))
        {
            Response.Write("<Script>alert('xoa thanh cong');</Script>");
            load();
        }
        else
        {
            Response.Write("<Script>alert('xoa khong thanh cong');</Script>");
        
            
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        load();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        load();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        
        Khachhangbo bo = new Khachhangbo();
        KhachhangData kh = new KhachhangData();
        kh.ID1 = int.Parse(GridView1.DataKeys[e.RowIndex].Value.ToString());
       // kh.USERNAME1=(GridView1.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox).Text;
        kh.CMND1 =int.Parse( (GridView1.Rows[e.RowIndex].Cells[3].Controls[0] as TextBox).Text);
        kh.HOTEN1 = (GridView1.Rows[e.RowIndex].Cells[4].Controls[0] as TextBox).Text;
        kh.DIENTHOAI1 = (GridView1.Rows[e.RowIndex].Cells[5].Controls[0] as TextBox).Text;
        kh.TINHTHANH1 = (GridView1.Rows[e.RowIndex].Cells[6].Controls[0] as TextBox).Text;
        kh.NGAYDANGKY1 = (GridView1.Rows[e.RowIndex].Cells[7].Controls[0] as TextBox).Text;
        kh.SONGUOI1 =int.Parse( (GridView1.Rows[e.RowIndex].Cells[8].Controls[0] as TextBox).Text);
        kh.MATOUR1 =int.Parse( (GridView1.Rows[e.RowIndex].Cells[9].Controls[0] as TextBox).Text);

        if (bo.Update(kh))
        {
            Response.Write("<Script>alert('Cap nhat thanh cong');</Script>");
            GridView1.EditIndex = -1;
            load();
        }
        else
        {
            Response.Write("<Script>alert('Cap nhat khong thanh cong');</Script>");
        }

    }
}
