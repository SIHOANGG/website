﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;

public partial class Tour : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ToursData tour = new ToursData();
        tour.TENTOUR1 = txtTentour.Text;
        tour.MOTA1 = txtMota.Text;
        tour.NOIDUNG1 = Editor1.Text;
        tour.SONGAY1 = int.Parse(txtSongay.Text);
        tour.PHUONGTIEN1 = txtPhuongtien.SelectedValue;
        tour.TONGSO1 = int.Parse(txttongso.Text);
        tour.NGAYKHOIHANH1 =DateTime.Parse(txtngaykhoihanh.Text);
        tour.MA1 = DropDownList1.SelectedValue;
        tour.GIACA1 = int.Parse(txtGiaca.Text);
        tour.DIEMDEN1 = txtdiemden.Text;
        string sTenfile;
        //Tách lấy tên tập tin
        sTenfile = txtHinhanh.FileName;
        //Thực hiện chép tập tin lên thư mục Upload
        txtHinhanh.SaveAs(MapPath("~/image/" + sTenfile));
        tour.HINHANH1 = sTenfile;
        ToursBO bo = new ToursBO();
        if (bo.inserttour(tour))
        {
            Response.Write("<Script>alert('đăng tour mới thành công')</Script>");
            

        }
        else
        Response.Write("<Script>alert('đăng tour mới thành công')</Script>");
    }
}
