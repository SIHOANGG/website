﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.Contents["username"] != null)
        {
            Response.Redirect("Default.aspx");
        }
        else
        {
            bang2.Visible = false;
        }
    }
    protected void bt_register_Click(object sender, EventArgs e)
    {
        if (Session.Contents["username"] == null)
        {
            kiemtra();
        }
        else
        {
            Response.Redirect("Default.aspx");
        }
    }
    protected void kiemtra()
    {
        taikhoanbo bo = new taikhoanbo() ;
        Taikhoandata tk=new Taikhoandata();
        tk.USERNAME1=txt_username.Text;
        tk.PASS1=mahoa.md5(txt_pass1.Text);
        tk.EMAIL1=txt_email.Text;
        tk.ADDRESS1=txt_address.Text;
        tk.GENDER1=DropDownList1.SelectedValue.ToString();

        if(bo.dangkybo(tk))
        {
            Response.Write("<Script>aler('Dang ky thanh cong');</Script>");
            Response.Redirect("Login.aspx");
        }
        else
            Response.Write("<Script>aler('Lỗi trong quá trình đăng ký');</Script>");
    }
    /*protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Khachhangbo bo = new Khachhangbo();
        Button bt = (Button)sender;
        int id = int.Parse(bt.CommandArgument);
        if (bo.DeleteOrRetose(id, true))
        {
            Response.Write("<Script>aler('xoa thanh cong');</Script>");
        }
        else
        {
            Response.Write("<Script>aler('xoa khong thanh cong');</Script>");

        }
    }*/


}
