﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class Changepassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtOldPassword.Text = "";
        if (Session["username"] == null)
            Response.Redirect("Login.aspx");
    }

    protected void btnChangepassword_Click(object sender, EventArgs e)
    {
        string username = Session["username"].ToString();
        string oldpass = Session["pass"].ToString();
        if (oldpass.Equals(mahoa.md5(txtOldPassword.Text)))
        {
            taikhoanbo bo = new taikhoanbo();
            if (bo.updatechangepass(username, mahoa.md5(txtNewPassword.Text)))
            {
                Response.Write("<Script>alert('Thay đổi mật khẩu thành công.');</Script>");
            }
            else
                Response.Write("<Script>alert('có lỗi xãy ra trong quá trình thay đổi mật khẩu, vui lòng cập nhật lúc khác.');</Script>");
        }
        else
        {
            Response.Write("<Script>alert('Mật khẩu cũ không đúng.');</Script>");
        }
    }
  
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtNewPassword.Text = "";
        txtOldPassword.Text = "";
        txtConfirmPassword.Text = "";
    }
}
